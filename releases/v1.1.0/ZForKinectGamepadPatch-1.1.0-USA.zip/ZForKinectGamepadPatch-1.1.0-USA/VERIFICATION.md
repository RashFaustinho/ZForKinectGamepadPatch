# Regional verification — USA 1.1.0

Patch SHA-256: `860d9f2212c91c8c68772773731dde80818741932c5e2a85c0dbe15470f594d9`. Module: `8FDD4F4AB147612A`.

- Fifteen PPC regression suites passed on this exact patch.
- The added side/idle-tail suite executes the original native melee and ranged
  setters, checks eight alternating attacks of each type, and verifies the
  selected hand survives native action/side reset in all joint buffers.
- The exact public startup payload was read back in Xenia, without LOCAL
  diagnostic hooks. All thirteen native 128×128 texture resources matched.
- Genuine pad navigation entered Score Attack. Native X requests alternated
  sides in close and ranged combat. Read-only geometry checks and Vulkan
  captures support the scoped visual findings in `validation.json`.

The native side sequence is shared across close and ranged attacks, so a later
ranged sample can start on the left after an odd number of nearby requests.
A selected input, rendered effect and successful damage avoidance are distinct.
Favorable/unfavorable QTE rules and native timing remain in force.

Vulkan and Null findings are identified separately in the report. Some software
Vulkan runs request smaller internal display dimensions; command-line settings
are recorded separately from window size and native glyph dimensions. Actual
render-target resolution has not been independently measured.
No exhaustive every-character/campaign, physical-controller or Windows claim.
