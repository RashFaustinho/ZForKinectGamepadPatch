# Regional verification — Europe 1.1.2

Patch SHA-256: `581c724308eaceb05973508f913151690a3c2ad49c8c634a8b8b27b49f548ff3`. Module: `C9561ED1F9AFFED4`.

- Nineteen CPU suites passed on this exact regional patch, including 168
  clash/catalog/fallback cases and the actual native mash selectors.
- Public startup bytes and all thirteen GPU resources were read back in Xenia.
  Four faces are 256×256 RGBA8; nine other glyphs retain their BC3 bytes.
- The old B texture had 285 reddish contour texels in the measured annulus;
  the new authored RGBA texture has zero under the same color predicate.
- European Vulkan captured the native Super-mash UI with X and hidden poses.
  This is a LOCAL display fixture that selects an existing tutorial group and
  requests its panel's native show animation. It does not reproduce a real
  Super clash, its progress/victory, or the whole N18 versus N17 encounter.
- Regular B/X gameplay was captured on an earlier candidate with the exact
  same RGBA path; only the two final Super-widget hooks were subsequently added.
- The validated guard and attack payloads remain byte-identical to 1.1.1.

See `validation.json` for scope and artifact hashes. No new every-character,
campaign, Windows/D3D12, physical-controller or USA graphical claim is made.
