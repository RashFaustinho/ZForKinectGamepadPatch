# Regional verification — USA 1.1.1

Patch SHA-256: `4ab918aeffd483e0898ee41b54193d378bd6ecad035c4dbcc46e8f4f0521eeb1`. Module: `8FDD4F4AB147612A`.

- Fifteen regression suites plus alternating-arm, guard-pose and native texture
  ownership suites passed on this exact patch (eighteen suites in total).
- All public startup code/data was read back without LOCAL diagnostic hooks.
  Thirteen loaded textures match their sources: A/B/X/Y at 256×256, nine others
  at 128×128. Allocation failure and truncated-stream cleanup are checked.
- Native B guard activation and matching joint buffers were observed in Xenia.
  European Vulkan screenshots show the tucked stance and the new B glyph;
  American guard data uses Null GPU, without a USA graphical claim.
- Normal X code and motion tables are byte-identical to 1.1.0. That version's
  native melee/ranged observations are historical evidence; the new patch's
  native setters are rechecked by the alternating-arm CPU suite.

The reported straight-arm defect was not reproduced in the original European
Goku scenario: the old guard was also raised there. This update supplies a
tighter symmetric pose; it does not claim a diagnosed cause for that report.
See `validation.json` for exact observations. No exhaustive every-character,
campaign, Windows/D3D12 or physical-controller verification is claimed.
