# IMPORTANT DISCLAIMER: BUILT PRIMARILY WITH AI

Most reverse engineering, patch code, automation and documentation was produced
by OpenAI Codex under human direction and with gameplay feedback from
RashFaustinho. AI-generated findings can contain mistakes. This is an unofficial
fan project; original project work is MIT-licensed in the source repository.

# Dragon Ball Z for Kinect — Gamepad Patch 1.1.1 (USA)

**For the American (USA) edition of the Xbox 360 game.**
Title ID: `4E4D084E`. Executable module hash: `8FDD4F4AB147612A`.
Other builds and Title Updates are unverified. Tested with Xenia Canary b735063
on Linux. Physical USB controllers and Windows/D3D12 were not tested here.

## Install

1. Close Xenia and back up your save.
2. Find its Storage root in the startup log. Remove older versions of this
   project's patch from its `patches` directory.
3. Copy `patches/4E4D084E.gamepad.usa.patch.toml` into that directory.
4. Enable `apply_patches = true` under `[General]` in Xenia's configuration.
5. Select your local profile, configure the controller normally and launch
   your own copy of this edition.

The log should show `Gamepad conversion 1.1.1 (USA)`.
No ISO editing, executable replacement or Python installation is required.
Use one current regional version of the project at a time.

## Changes

A/B/X/Y now use actual 256×256 BC3 textures (four times the previous pixel
count), with linear filtering and the same compact drawing footprint.
Separate buffers are owned and released by the game's native texture system.
B uses a symmetric tucked guard with raised fists near the face. Normal X
right/left attack selection and motion tables remain byte-identical to 1.1.0.

## Controls



| Context | Input | Action |
| --- | --- | --- |
| Menus | Left stick / A / B | Select / confirm / back |
| Battle start | X | Perform the required starting punch |
| Close range | X | Normal punches |
| Long range | X | Normal Ki Blasts |
| Close range | Hold Y, then release | Charge and throw a charged punch |
| Long range | Y | Heavy Ki Blast |
| Close range | RT | Uppercut |
| Battle | Hold B | Guard |
| Battle | Left stick left / right | Lateral steps |
| Battle | A | Request a rapid approach |
| Battle | Hold D-pad Down | Charge Ki |
| Battle | Right-stick Down impulse | Lower Super, with at least 50 Ki |
| Battle | Right-stick Up impulse | Upper Super, with 100 Ki |
| Contextual choices | Displayed LB/RB/LT/RT or other button | Select the corresponding action |
| Opponent Super | B / left stick left / indicated right-stick direction | Guard / evade / counter |
| Great Ape Vegeta QTEs | Hold RT when requested | Supply the special boss gesture/pose input |

A Super request below the required Ki threshold is ignored, rather than queued. Super Attacks use a single stick impulse, without hold-to-charge or release-to-fire. Player Super preparation artwork remains original. The first-person arms use authored generic trajectories with the game's original meshes; they are not extracted CPU attack clips.

The native prohibition sign marks an unfavorable option. Recognizing its button does not guarantee a successful defense. In the launch-defense choice, B now takes priority over a left stick that remains tilted.


## Card Reader and verification

[CARD_READER.md](CARD_READER.md) contains the power-up button map and the required
read → B → save → re-enter cycle for each counted press.
To remove a power-up: **Options → Reset Power-Up Card → Yes**.

[VERIFICATION.md](VERIFICATION.md), `validation.json`, `manifest.json` and
`SHA256SUMS` describe this exact regional artifact and the limits of its checks.
Source and research: https://github.com/RashFaustinho/ZForKinectGamepadPatch

Patch size: 90,372 bytes. SHA-256: `4ab918aeffd483e0898ee41b54193d378bd6ecad035c4dbcc46e8f4f0521eeb1`.

## Optional USA save

See [the save guide](optional-save/README.md) before replacing DB_SAVE. Back up your existing save first. No power-up is active.
